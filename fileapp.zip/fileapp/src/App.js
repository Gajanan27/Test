import { Component } from 'react';
import FileManager from './component/filemanager';
import DataView from './component/dataview';
import './App.css';
import Alert from '@material-ui/lab/Alert';

export const REPLACE_MSG = 'File successfully replaced';
export const FILE_UPLOADED = 'File successfully uploaded';
export const FILE_DELETED = 'File deleted successfullt';
export const SELECTED_FILE_ID_NE = 'Selected File ID Not exist for delete';

class App extends Component {

  state = {
    fileList: [],
    alert: null,
    message: ''
  };

  getData = (data, operation, fileId, isFileSelected) => {
    if (!isFileSelected) {
      this.setState({
        fileList: this.state.fileList,
        alert: 'warning',
        message: 'File not select for upload'
      })
    }
    let files = this.state.fileList;
    let index = -1;
    if (operation === 'replace') {
      const replaceIndex = files.findIndex(file => (file.name).split('.')[0] === data.name);
      files.splice(replaceIndex, 1);
    } else if (operation === 'create' && files.length > 0) {
       index = files.findIndex(file => file.name === data.name);
    }
    if (fileId && data) {
      data['fileId'] = fileId;
    }
    if (index === -1 && data) {
      files.push(data);
      this.setState({
        fileList: files,
        alert: 'success',
        message: operation === 'replace' ? REPLACE_MSG : index >= 0 ? 'Already exist' : FILE_UPLOADED
      })
    }
  }

  actionOnData = (operation, fileId) => {
    console.log(operation);
    const files = Object.assign([], this.state.fileList);
    let newFiles = [];
    let isItemExist;
    if (operation === 'delete') {
      isItemExist = files.findIndex(file => (file.name).split('.')[0] === fileId);
      newFiles = files.filter(file => (file.name).split('.')[0] !== fileId);
    }
    this.setState({
      fileList: newFiles,
      alert: isItemExist >= 0 ? 'success' : 'warning',
      message: isItemExist >= 0 ? FILE_DELETED : SELECTED_FILE_ID_NE
    })
  }

  render () {
    return (
        <div className="App">
          <header className="App-header">
            File Manager
          </header>
          <div>
            { this.state.alert === 'error' ? <Alert severity="error">{this.state.message}</Alert> : ''}
            { this.state.alert === 'success' ? <Alert severity="success">{this.state.message}</Alert> : ''}
            { this.state.alert === 'warning' ? <Alert severity="warning">{this.state.message}</Alert> : ''}
            <FileManager sendData= {this.getData} actionOnData={this.actionOnData} />
            <DataView data={this.state.fileList}></DataView>
          </div>
        </div>
      );
    }
}

export default App;
