import React, {Component, Fragment} from 'react';
import axios from 'axios';

function submitForm (contentType, data, setResponse) {
	axios({
	url: `https://www.example.com/endpoints/v1/file_operation`,
	method: 'POST',
	data: data,
	headers: {
		'Content-Type': contentType
	}
	}).then((response) => {
		setResponse(response.data);
	}).catch((error) => {
		setResponse("error");
	})
}

async function uploadWithJSON(file, operation, fileId) {
	const toBase64 = file => new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = () => resolve(reader.result);
		reader.onerror = error => reject(error);
	});
	const data = {
		data: await toBase64(file),
		fileid: fileId,
		operation: operation
	}
	submitForm("application/json", data, (msg) => console.log(msg));
}

class FileManager extends Component {

	state = {
	    selectedFile: null,
		operation: null,
		fileId: null
	};
	
	// On file select (from the pop up)
	onFileChange = event => {
	    this.setState({ selectedFile: event.target.files[0] });
	};


	
	onFileUpload = () => {
		if (this.state.selectedFile) {
			const formData = new FormData();
			formData.append(
				"myFile",
				this.state.selectedFile,
				this.state.selectedFile.name
			);

			uploadWithJSON(this.state.selectedFile, this.state.operation, this.state.fileId)
			this.props.sendData(this.state.selectedFile, this.state.operation, this.state.fileId);
		} else {
			this.props.sendData(this.state.selectedFile, this.state.operation, this.state.fileId, false);
		}
	};

	onOperationChange = (operation) => {
		console.log(operation);
		this.setState({ 
			...this.state,
			selectedFile: null,
			operation
		});
	}

	fileIDChange = (event) => {
		console.log(event);
		this.setState({ 
			...this.state,
			fileId: event.target.value
		});
	}
	
	render() {
		return (
			<Fragment>
				<h3>File Details</h3>
				<div className="mainContent">
				{ this.state.operation !== 'create' ? 
					<div>
						<label className="customLabel">File ID:  </label>
						<input type="text" value={this.state.fileId} onChange={this.fileIDChange}/>
					</div>
					: ''
		}
					<div>
						<label className="customLabel">Operation:  </label>
						<select id ='select' onChange={e => this.onOperationChange(e.target.value)} style={{width: '152px'}}>
						     <option value="select">Select</option>
							<option value="create">Create</option>
							<option value="read">Read</option>
							<option value="replace">Replace</option>
							<option value="delete">Delete</option>
						</select>
					</div>
					{ this.state.operation === 'create' ||  this.state.operation === 'replace' ? 
					<div>	
						<label className="customLabel">File:  </label>
						<input type="file" onChange={this.onFileChange} /><button onClick={this.onFileUpload}>Upload!</button>
					</div>
					: ''
				}
				{ this.state.operation === 'read' ||  this.state.operation === 'delete' ? 
					<button onClick={e => this.props.actionOnData(this.state.operation, this.state.fileId)}>{this.state.operation}</button>
				: ''
				}
				</div>
			</Fragment>
		);
	}
}

export default FileManager;
